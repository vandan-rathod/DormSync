# DormSync MySQL 8 schema package

## Contents
- `tables/`: one YAML file per table, in dependency order. Each file uses the flat field-property style (`table` + `groups.main`) used by the existing YAML schema workflow, with table-level `primary_key`, `unique_constraints`, `checks`, and `indexes` where needed.
- `dormsync_schema.sql`: reference MySQL 8 DDL, including foreign keys, unique constraints, checks, and indexes.
- `dormsync_transactions.sql`: transactional room-allocation procedure plus complaint-status audit triggers. Install after the schema.

## Tables (18)
- `hostels`
- `floors`
- `rooms`
- `residents`
- `staff`
- `roles`
- `users`
- `user_roles`
- `hostel_staff_assignments`
- `room_allocations`
- `fee_types`
- `fee_invoices`
- `invoice_items`
- `payments`
- `payment_allocations`
- `complaint_categories`
- `complaints`
- `complaint_status_history`

## Important generator compatibility note
The YAML preserves the established `table` / `groups` / flat-column-property shape. Composite primary keys and table-level unique/check/index metadata require your `SQLGenerator` to support the corresponding top-level keys (`primary_key`, `unique_constraints`, `checks`, and `indexes`). Column foreign keys are available as `foreign_key: {table, column, on_delete, on_update}`. If your current generator only handles `groups` and per-column properties, use the SQL reference file as the complete constraint reference and extend the generator for table-level constraints before treating YAML-generated DDL as production-ready.

## Rules that YAML / ordinary constraints cannot fully enforce alone
1. **Room capacity and resident overlap:** `sp_create_room_allocation` in `dormsync_transactions.sql` locks the room and resident rows, checks peak concurrent occupancy and overlapping resident allocations, and inserts within one transaction. Route allocations through this procedure and restrict direct writes to `room_allocations`; otherwise callers can bypass enforcement.
2. **Payment allocation totals:** for successful payments, sum of `payment_allocations.allocated_amount` must not exceed `payments.amount`; allocated amounts against an invoice must not exceed its total minus successful allocations. Lock payment and invoice rows and validate transactionally.
3. **Payment/invoice ownership:** ensure the payment's `resident_id` matches the resident on the invoice being paid. This cross-table condition needs application transaction logic or a carefully designed trigger.
4. **Invoice status transitions and totals:** only issue invoices with at least one line item; do not edit issued invoice line items without a controlled adjustment workflow. Derive totals from line items.
5. **Complaint audit:** the supplied triggers append complaint creation and status changes to `complaint_status_history` in the same transaction. Set the connection session variable `@dormsync_user_id` to the authenticated user ID before writes so the audit row records the actor.
6. **Resolved timestamps:** set `resolved_at` consistently when status enters `RESOLVED` or `CLOSED`, and clear or retain it according to an explicit reopening policy.
7. **Authentication:** hash passwords with a modern password-hashing algorithm (Argon2id or bcrypt); never store plaintext passwords. Authorization must be enforced in the application, not by role names alone.
8. **Deletion and historical integrity:** avoid deleting residents, staff, invoices, payments, allocations, and audit history where records must be retained. Prefer status changes or archival.
9. **Room/hostel compatibility:** validate room gender policy and resident eligibility during allocation; these rules depend on rows across multiple tables.

## Implementation notes
- Requires MySQL 8.0.16+ for enforced `CHECK` constraints.
- `ENUM` values are embedded in SQL type strings.
- `AUTO_INCREMENT` is represented as `generated: AUTO_INCREMENT`. Confirm your generator maps this property to MySQL `AUTO_INCREMENT`.
- Index names are explicit and unique per table.
- The SQL files are reference implementations; test them against the exact MySQL minor version and your migration workflow before production use. The transaction routine covers allocation insertion; fee-allocation limits and payment/invoice ownership still need equivalent transactional service logic or dedicated procedures.
